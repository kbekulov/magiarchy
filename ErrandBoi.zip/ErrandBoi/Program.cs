﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace ErrandBoi
{
    static class Globals
    {
        public static string filepath = @"C:\ErrandBoi\paste\";
    }
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }

        public static void CreatePaste()
        {
            string filename = Globals.filepath + DateTime.Now.ToString("yyyyMMdd-HHmmss") + "_" + Environment.UserName + "_Paste.txt";

            if (!File.Exists(filename)) // If file does not exists
            {
                File.Create(filename).Close(); // Create file
                using (StreamWriter sw = File.AppendText(filename))
                {
                    sw.WriteLine(Clipboard.GetText()); // Write text to .txt file
                }
            }
            else // If file already exists
            {
            }
        }

    }
}
