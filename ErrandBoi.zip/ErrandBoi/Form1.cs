﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Diagnostics;

namespace ErrandBoi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            //delete old

            string[] files = Directory.GetFiles(Globals.filepath);

            foreach (string file in files)
            {
                FileInfo fi = new FileInfo(file);
                if (fi.LastAccessTime < DateTime.Now.AddDays(-7))
                    fi.Delete();
            }

            listView1.View = View.Details;
            listView1.Columns.Add("Value shared", 290, HorizontalAlignment.Left);
            listView1.Columns.Add("By user", 70, HorizontalAlignment.Left);
            listView1.Columns.Add("On", 130, HorizontalAlignment.Left);
            listView1.Columns.Add("Filename", 0, HorizontalAlignment.Left);
            button2_Click(null, null);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Program.CreatePaste();
            button2_Click(null, null);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            listView1.Items.Clear();

            string[] files = Directory.GetFiles(Globals.filepath);
            foreach (string file in files)
            {

                string fileName = Path.GetFileNameWithoutExtension(file);
                ListViewItem item = new ListViewItem(File.ReadAllText(Globals.filepath + fileName + ".txt").Trim());
                item.Tag = file;
                item.SubItems.Add(Regex.Match(fileName, @"_(.+?)_").Groups[1].Value);
                item.SubItems.Add(DateTime.ParseExact(fileName.Substring(0, 15), "yyyyMMdd-HHmmss", null).ToString());
                item.SubItems.Add(fileName + ".txt").ToString();
                listView1.Items.Insert(0, item);

            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count == 0)
                return;

            string firstSelectedItem = listView1.SelectedItems[0].SubItems[3].Text;
            Process.Start("notepad.exe", Globals.filepath + firstSelectedItem);
        }
    }
}
